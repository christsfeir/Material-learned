/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetp1;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Stroke;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;
import static java.util.Collections.list;
import javax.swing.JComponent;

/**
 * Component for drawing
 *
 * @author Najoua
 */
public class DrawArea extends JComponent {

    /**
     * Image sur laquelle on va dessiner
     */
    private Image image;
    //  public rectangle2D
    /**
     * utilisé pour dessiner
     */
    static Graphics2D g2;
    private int choixForme = 0;
    private int currentX, currentY, oldX, oldY;

    int verificateur = 0;

    public DrawArea() {
        // setDoubleBuffered(false);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                //save coordonnées de x et de Y, quand la souris is pressed 
                oldX = e.getX();
                oldY = e.getY();

                int pinceau = (int) Tp1.jSpinner1.getValue();
                int pinceau2 = (int) Tp1.jSpinner3.getValue();
                
                
                //liste.add(new listeAction(10000,10000));
                
             listePressed.add(new listeAction(e.getX(), e.getY()));
               listePressed.add(new listeAction(0, 0));
               
               
                if (choixForme == 0) {//ligne normale
                    g2.fillRect(oldX, oldY, pinceau + 10, pinceau2 + 10);
                }
                if (choixForme == 1) {//rectangle
                    g2.fillRect(oldX, oldY, pinceau + 10, pinceau2 + 10);
                }
                if (choixForme == 2) {//cercle
                    g2.fillOval(oldX, oldY, pinceau + 10, pinceau2 + 10);
                }
                if (choixForme == 3){
                    g2.fillPolygon(new int[]{oldX - 10, oldX, oldX + 10},
                    new int[]{oldY + 10, oldY - 10, oldY + 10},3);
                    }
                repaint();
            }
            //  }

        });

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(java.awt.event.MouseEvent e) {
                //coord x, y quand drag mouse
                currentX = e.getX();
                currentY = e.getY();

                if (g2 != null) {
                    //dessine une ligne si g2 est non null

                    int pinceau = (int) Tp1.jSpinner1.getValue();
                    int pinceau2 = (int) Tp1.jSpinner3.getValue();
                    
                    
                    int pinceauOpacte = (int) Tp1.jSpinner2.getValue();

                    double opaque = 1 - ((pinceauOpacte * 1.0) / 100);

                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) (opaque)));

                    liste.add(new listeAction(e.getX(), e.getY()));
                     listePressed.add(new listeAction(e.getX(), e.getY()));

                    //refresh draw area to repaint
                    if (choixForme == 0) {//ligne normale
                        g2.fillRect(oldX, oldY, pinceau + 10, pinceau2 + 10);

                    }
                    if (choixForme == 1) {//rectangle
                        g2.fillRect(oldX, oldY, pinceau + 10, pinceau2 + 10);
                    }
                    if (choixForme == 2) {//cercle
                        g2.fillOval(oldX, oldY, pinceau + 10, pinceau2 + 10);
                    }
                    if (choixForme == 3){
                    g2.fillPolygon(new int[]{oldX - 10, oldX, oldX + 10},
                    new int[]{oldY + 10, oldY - 10, oldY + 10},3);
                    }
                    Stroke s = g2.getStroke();
                    g2.setStroke(new BasicStroke(pinceau));

                    repaint();
                    //store current coord x, Y as old x, y
                    oldX = currentX;
                    oldY = currentY;

                }
            }

        });

    }

    @Override
    protected void paintComponent(Graphics g) {
        if (image == null) {
            image = createImage(getSize().width, getSize().height);
            g2 = (Graphics2D) image.getGraphics();

            clear();
        }

        g.setClip(150, 55, 400, 400);
        g.drawImage(image, 0, 0, null);

    }

    public void clear() {
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
        g2.setPaint(Color.white);
        g2.fillRect(0, 0, getSize().width, getSize().height);
        g2.setPaint(Color.black);

        repaint();


    }

    public void red() {
        g2.setPaint(Color.red);
    }

    public void black() {
        g2.setPaint(Color.black);
    }

    public void magenta() {
        g2.setPaint(Color.magenta);

    }

    public void green() {
        g2.setPaint(Color.green);

    }

    public void blue() {
        g2.setPaint(Color.blue);

    }

    public void white() {
        g2.setPaint(Color.white);
    }

    public void yellow() {
        g2.setPaint(Color.yellow);
    }

    public void couleur(Color color) {
        g2.setPaint(color);
    }

    public void rectangle() {
        choixForme = 1;
    }

    public void cercle() {
        choixForme = 2;
    }

    void Definir(Color color) {
        g2.setPaint(color);
    }

    public void setBackground(Color color) {
        g2.setPaint(color);
        g2.fillRect(0, 0, getSize().width, getSize().height);
        Color c;
        repaint();
        
    }

    void remplissage() {
        Color c = (Color) g2.getPaint();

        setBackground(c);
        Tp1.couleurEfface = c;
    }
    ArrayList<listeAction> liste = new ArrayList<listeAction>();
    ArrayList<listeAction> listePressed = new ArrayList<listeAction>();

    void annuler() {
     int pinceau = (int) Tp1.jSpinner1.getValue();
     int pinceau2 = (int) Tp1.jSpinner3.getValue();
        g2.setPaint(Tp1.couleurEfface);

       
       int a =0;
       int total = 0;
       int bonus = 0;
       if (total != 0){
          bonus = total; 
       }
       
        for (int i = liste.size()-1-total; i >= 0;i--) {
           
                g2.fillRect(liste.get(i).getX(), liste.get(i).getY(), pinceau+ 10, pinceau2 + 10);
                
            if (listePressed.get(i).getX() == 0){
                 a = liste.size() - i;
                g2.fillRect(listePressed.get(i-1).getX(), listePressed.get(i-1).getY(), pinceau+ 10, pinceau2 + 10);
                
                i = 0;
            }
            
        }
        
        total += a;
        
        repaint();
        g2.setPaint(Color.BLACK);

    }
    void repeter() {
        
          int pinceau = (int) Tp1.jSpinner1.getValue();
          int pinceau2 = (int) Tp1.jSpinner3.getValue();
           g2.setPaint(Color.BLACK);
       
            int a =0;
       int total = 0;
       int bonus = 0;
       if (total != 0){
          bonus = total; 
       }
       
        for (int i = liste.size()-1-total; i >= 0;i--) {
           
                g2.fillRect(liste.get(i).getX(), liste.get(i).getY(), pinceau+ 10, pinceau2 + 10);
                
            if (listePressed.get(i).getX() == 0){
                 a = liste.size() - i;
                g2.fillRect(listePressed.get(i-1).getX(), listePressed.get(i-1).getY(), pinceau+ 10, pinceau2 + 10);
                
                i = 0;
            }
            
        }
        
        total += a;
           
           
           
           
           
        repaint();
        g2.setPaint(Color.BLACK);
        
        
    }

    void triangle() {
        choixForme = 3;
    }
 public class listeAction {

        int x;
        int y;

        public listeAction(int x, int y) {
            this.x = x;
            this.y = y;
        }
    
        
        public int getX() {
            return x;
        }

        public int getY() {
            return y;
        }

       

    }

    }

   


