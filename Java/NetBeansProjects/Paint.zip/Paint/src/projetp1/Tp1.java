/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetp1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JToolBar;
import javax.swing.SpinnerNumberModel;

/**
 *
 * @author Christian Sfeir
 */
public class Tp1 extends javax.swing.JFrame {

    /**
     * Creates new form PaintJFrame
     */

    public Tp1() {
        initComponents();
       
    }

    

    private void initComponents() {

        //Menu Bar
        jMenuBar1 = new JMenuBar();
        //-------------------------<Menu fichier>---------------------------
        jMenuFichier = new JMenu("Fichier");
        
        
        jMenuItemNouveau = new JMenuItem("Nouveau...");
          jMenuItemNouveau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemNouveauActionPerformed(evt);
            }
            private void jMenuItemNouveauActionPerformed(ActionEvent evt) {
                Tp1 nouveau = new Tp1();
                nouveau.setVisible(true);
                nouveau.setLocation(12,12);
            }
        });
        
        jMenuFichier.add(jMenuItemNouveau);
        jMenuItemOuvrir = new JMenuItem("Ouvrir...");
        jMenuFichier.add(jMenuItemOuvrir);
        jMenuItemEnregistrer = new JMenuItem("Enregister");
        jMenuFichier.add(jMenuItemEnregistrer);
        jMenuItemEnregistrerSous = new JMenuItem("Enregistrer sous...");
        jMenuFichier.add(jMenuItemEnregistrerSous);
        
        //Quitter
        jMenuItemQuitter = new JMenuItem("Quitter");
        jMenuFichier.add(jMenuItemQuitter);
        jMenuItemQuitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemQuitterActionPerformed(evt);
            }
        
            private void jMenuItemQuitterActionPerformed(ActionEvent evt) {
                System.exit(0);
            }
        });
                
        
        
        
        //Menu Édition
        jMenuEdition = new JMenu("Edition");
        jMenuItemAnnuler = new JMenuItem("Annuler");
        jMenuItemAnnuler.addActionListener((ActionEvent e) -> {
            drawArea.annuler();
        });
        jMenuEdition.add(jMenuItemAnnuler);
        jMenuItemRepeter = new JMenuItem("Répéter");
        jMenuEdition.add(jMenuItemRepeter);
        jMenuItemRepeter.addActionListener((ActionEvent e) -> {
            drawArea.repeter();
        });
        
        //Menu Document
        jMenuDocument = new JMenu("Document");
        jMenuItemProprietes = new JMenuItem("Propriétés...");
        jMenuDocument.add(jMenuItemProprietes);
         jMenuItemProprietes.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemProprietesActionPerformed(evt);
            }
            private void jMenuItemProprietesActionPerformed(ActionEvent evt) {
               Definir.definirPinceau = true;
                Propriete propriete = new Propriete();
                propriete.setVisible(true);
                propriete.setLocationRelativeTo(null);

            }
        });
        
        
        
        jMenuItemVider = new JMenuItem("Vider");
        jMenuDocument.add(jMenuItemVider);
        jMenuItemVider.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemViderActionPerformed(evt);
            }
            private void jMenuItemViderActionPerformed(ActionEvent evt) {
                drawArea.clear();
            }
        });
        
        
        //Menu Formes
        jMenuFormes = new JMenu("Formes");
        jMenuItemRectangle = new JMenuItem("Rectangle");
        jMenuFormes.add(jMenuItemRectangle);
        jMenuItemEllipse = new JMenuItem("Ellipse");
        jMenuFormes.add(jMenuItemEllipse);
        jMenuItemTriangle = new JMenuItem("Triangle");
        jMenuFormes.add(jMenuItemTriangle);
        jMenuItemTriangle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBoutonBlancActionPerformed(evt);
            }
            private void jBoutonBlancActionPerformed(ActionEvent evt) {
                drawArea.couleur(couleurEfface);
            }
        });
        
        
        jMenuItemRemplissage = new JMenuItem("Remplissage");
        jMenuFormes.add(jMenuItemRemplissage);
        //Menu Couleurs
        jMenuCouleurs = new JMenu("Couleurs");
        jMenuItemEfface = new JMenuItem("Efface");
        jMenuCouleurs.add(jMenuItemEfface);
        jMenuItemEfface.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBoutonBlancActionPerformed(evt);
            }
            private void jBoutonBlancActionPerformed(ActionEvent evt) {
                drawArea.couleur(couleurEfface);
            }
        });
        
        
        
        jMenuItemNoir = new JMenuItem("Noir");
        jMenuCouleurs.add(jMenuItemNoir);
          jMenuItemNoir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemNoirActionPerformed(evt);
            }
            private void jMenuItemNoirActionPerformed(ActionEvent evt) {
                drawArea.black();
            }
        });
        jMenuItemBlanc = new JMenuItem("Blanc");
        jMenuItemBlanc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemBlancActionPerformed(evt);
            }
            private void jMenuItemBlancActionPerformed(ActionEvent evt) {
                drawArea.white();
            }
        });
        jMenuCouleurs.add(jMenuItemBlanc);
        jMenuItemRouge = new JMenuItem("Rouge");
        jMenuItemRouge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemRougeActionPerformed(evt);
            }
            private void jMenuItemRougeActionPerformed(ActionEvent evt) {
                drawArea.red();
            }
        });
        jMenuCouleurs.add(jMenuItemRouge);
        jMenuItemVert = new JMenuItem("Vert");
        jMenuItemVert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemVertActionPerformed(evt);
            }
            private void jMenuItemVertActionPerformed(ActionEvent evt) {
                drawArea.green();
            }
        });
        jMenuCouleurs.add(jMenuItemVert);
        jMenuItemBleu = new JMenuItem("Bleu");
        jMenuItemBleu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemBleuActionPerformed(evt);
            }
            private void jMenuItemBleuActionPerformed(ActionEvent evt) {
                drawArea.blue();
            }
        });
        jMenuCouleurs.add(jMenuItemBleu);
        jMenuItemJaune = new JMenuItem("Jaune");
        jMenuItemJaune.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemJauneActionPerformed(evt);
            }
            private void jMenuItemJauneActionPerformed(ActionEvent evt) {
                drawArea.yellow();
            }
        });
        jMenuCouleurs.add(jMenuItemJaune);
        jMenuItemDefinir = new JMenuItem("Definir...");
        jMenuCouleurs.add(jMenuItemDefinir);
        jMenuItemDefinir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemDefinirActionPerformed(evt);
            }
            private void jMenuItemDefinirActionPerformed(ActionEvent evt) {
               Definir couleur = new Definir();
               couleur.setVisible(true);
                
            }
        });
       
        
        
        
        //Menu ?
        jMenuApropos = new JMenu("?");
        jMenuItemapropos = new JMenuItem("À Propos");
        jMenuApropos.add(jMenuItemapropos);
        jMenuItemapropos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemaproposActionPerformed(evt);
            }
            private void jMenuItemaproposActionPerformed(ActionEvent evt) {
                
                JOptionPane.showMessageDialog(null,"Auteur:   Luke Woodley");
            }
        });
        
        
        
        
        //Racourcis Menu Fichier
        jMenuItemNouveau.setAccelerator(javax.swing.KeyStroke.
                getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemOuvrir.setAccelerator(javax.swing.KeyStroke.
                getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemEnregistrer.setAccelerator(javax.swing.KeyStroke.
                getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemEnregistrerSous.setAccelerator(javax.swing.KeyStroke.
                getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemQuitter.setAccelerator(javax.swing.KeyStroke.
                getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.ALT_MASK));

        //Racourcis Menu Edition
        jMenuItemAnnuler.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Z, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemRepeter.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Y, java.awt.event.InputEvent.CTRL_MASK));

        //Racourcis Menu Document 
        jMenuItemRectangle.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_1, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemEllipse.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_2, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemTriangle.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_3, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemRemplissage.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_4, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemEfface.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_0, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemNoir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_1, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemBlanc.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_2, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemRouge.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_3, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemVert.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_4, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemBleu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_5, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemJaune.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_6, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemDefinir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_9, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
////////images
        jMenuItemVider.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/clear.png")));
        jMenuItemRectangle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/rectangle.png")));
        jMenuItemEllipse.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ellipse.png")));
        jMenuItemTriangle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/triangle.png")));
        jMenuItemRemplissage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/fill.png")));
        jMenuItemEfface.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/eraser.png")));
        jMenuItemNoir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/black.png")));
        jMenuItemBlanc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/white.png")));
        jMenuItemRouge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/red.png")));
        jMenuItemVert.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/green.png")));
        jMenuItemBleu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/blue.png")));
        jMenuItemJaune.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/yellow.png")));
//tool Bar
        jToolBar1 = new JToolBar();

        jButtonRectangle = new JButton();
        jButtonRectangle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/rectangle.png"))); 
        jToolBar1.add(jButtonRectangle);
        jButtonRectangle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuButtonRectangleActionPerformed(evt);
            }
            private void jMenuButtonRectangleActionPerformed(ActionEvent evt) {
                drawArea.rectangle();
            }
        });

        jButtonEllipse = new JButton();
        jButtonEllipse.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ellipse.png"))); 
        jToolBar1.add(jButtonEllipse);
        jButtonEllipse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuButtonCercleActionPerformed(evt);
            }
            private void jMenuButtonCercleActionPerformed(ActionEvent evt) {
                drawArea.cercle();
            }
        });
        
        

        jButtonTriangle = new JButton();
        jButtonTriangle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/triangle.png")));
        jToolBar1.add(jButtonTriangle);
        jButtonTriangle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuButtonRemplissageActionPerformed(evt);
            }
            private void jMenuButtonRemplissageActionPerformed(ActionEvent evt) {
               drawArea.triangle();
                
            }
        });
        

        jButtonRemplissage = new JButton();
        jButtonRemplissage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/fill.png"))); 
        jToolBar1.add(jButtonRemplissage);
          jButtonRemplissage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuButtonRemplissageActionPerformed(evt);
            }
            private void jMenuButtonRemplissageActionPerformed(ActionEvent evt) {
               drawArea.remplissage();
                
            }
        });

        jButtonImage = new JButton();
        jButtonImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/pattern.png"))); 
        jToolBar1.add(jButtonImage);

        jButtonEfface = new JButton();
        jButtonEfface.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/eraser.png"))); 
        jToolBar1.add(jButtonEfface);
        jButtonEfface.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBoutonBlancActionPerformed(evt);
            }
            private void jBoutonBlancActionPerformed(ActionEvent evt) {
                drawArea.couleur(couleurEfface);
            }
        });
        
        

        jButtonNoir = new JButton();
        jButtonNoir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/black.png"))); 
        jToolBar1.add(jButtonNoir);
        jButtonNoir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBoutonNoirActionPerformed(evt);
            }
            private void jBoutonNoirActionPerformed(ActionEvent evt) {
                drawArea.black();
            }
        });
        
        

        jButtonBlanc = new JButton();
        jButtonBlanc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/white.png"))); 
        jToolBar1.add(jButtonBlanc);
        jButtonBlanc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBoutonBlancActionPerformed(evt);
            }
            private void jBoutonBlancActionPerformed(ActionEvent evt) {
                drawArea.white();
            }
        });
        
        jButtonRouge = new JButton();
        jButtonRouge.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/red.png"))); 
        jToolBar1.add(jButtonRouge);
        jButtonRouge.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBoutonBlancActionPerformed(evt);
            }
            private void jBoutonBlancActionPerformed(ActionEvent evt) {
                drawArea.red();
            }
        });
        
        

        jButtonVert = new JButton();
        jButtonVert.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/green.png"))); 
        jToolBar1.add(jButtonVert);
        jButtonVert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBoutonVertActionPerformed(evt);
            }
            private void jBoutonVertActionPerformed(ActionEvent evt) {
                drawArea.green();
            }
        });
        
        
        
        jButtonBleu = new JButton();
        jButtonBleu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/blue.png"))); 
        jToolBar1.add(jButtonBleu);
        jButtonBleu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBoutonBlueActionPerformed(evt);
            }
            private void jBoutonBlueActionPerformed(ActionEvent evt) {
                drawArea.blue();
            }
        });
        
        

        jButtonJaune = new JButton();
        jButtonJaune.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/yellow.png"))); 
        jToolBar1.add(jButtonJaune);
        jButtonJaune.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBoutonJauneActionPerformed(evt);
            }
            private void jBoutonJauneActionPerformed(ActionEvent evt) {
                drawArea.yellow();
            }
        });

        jButtonDefinir = new JButton();
        jButtonDefinir.setText("Definir....");
        jToolBar1.add(jButtonDefinir);
        jButtonDefinir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBoutonDefinirActionPerformed(evt);
            }
            private void jBoutonDefinirActionPerformed(ActionEvent evt) {
            
               Definir couleur = new Definir();
               couleur.setVisible(true);
               
               
               
            }
        });
        
        
        
        
        
        jLabelTaille = new JLabel();
        jLabelTaille.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/size.png"))); 
        jLabelTaille.setText("Taille");
        jToolBar1.add(jLabelTaille);
        
        jSpinner1 = new JSpinner();
        jSpinner1.setMinimumSize(new java.awt.Dimension(29, 45));
        jSpinner1.setPreferredSize(new java.awt.Dimension(70, 25));
        //jSpinner1.set
        jToolBar1.add(jSpinner1);
        
        jLabel1 = new JLabel();
        jLabel1.setText("x");
        jToolBar1.add(jLabel1);
        
        jSpinner3 = new JSpinner();
        jSpinner3.setMinimumSize(new java.awt.Dimension(29, 45));
        jSpinner3.setPreferredSize(new java.awt.Dimension(70, 25));
        jToolBar1.add(jSpinner3);
       

        
        jSeparator1 = new JSeparator(JSeparator.VERTICAL);
        
        jToolBar1.add(jSeparator1);
        
        jLabel2 = new JLabel();
        jLabel2.setText("Pression :");
        jToolBar1.add(jLabel2);
        
        jSpinner2 = new JSpinner();
        jSpinner2.setMinimumSize(new java.awt.Dimension(29, 45));
        jSpinner2.setPreferredSize(new java.awt.Dimension(70, 25));
        jToolBar1.add(jSpinner2);
        
        jButton1 = new JButton(); //clear
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/clear.png"))); 
        jButton1.setText("Vider");
        jToolBar1.add(jButton1);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBoutonViderActionPerformed(evt);
            }
            private void jBoutonViderActionPerformed(ActionEvent evt) {
                
                drawArea.clear();
           
            }
        });
        
        

        jToolBar1.setFloatable(false);
        jToolBar1.setRollover(true);

        jMenuBar1.add(jMenuFichier);
        jMenuBar1.add(jMenuEdition);
        jMenuBar1.add(jMenuDocument);
        jMenuBar1.add(jMenuFormes);
        jMenuBar1.add(jMenuCouleurs);
        jMenuBar1.add(jMenuApropos);

       
        drawArea = new DrawArea();
        this.setLayout(new BorderLayout());
        
        this.getContentPane().add(drawArea);
        this.add(jToolBar1, BorderLayout.NORTH);
 
        this.setJMenuBar(jMenuBar1);

        
        
        
        this.setResizable(false);
        this.setSize(700, 600);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        this.setTitle("Painator");
        this.setVisible(true);

    }

    // Variables declaration - do not modify  
    static Color couleurEfface = Color.WHITE;
    static DrawArea drawArea;
    private JButton jButton1, jButton3, jButtonBlanc, jButtonBleu, jButtonDefinir, jButtonEfface, jButtonEllipse, jButtonImage, jButtonJaune,
            jButtonNoir, jButtonRectangle, jButtonRemplissage, jButtonRouge,
            jButtonTriangle, jButtonVert;
    private JLabel jLabel1, jLabel2, jLabelTaille;
    private JMenu jMenuApropos, jMenuCouleurs, jMenuDocument,
            jMenuEdition, jMenuFichier, jMenuFormes;
    private JMenuBar jMenuBar1;
    private JToolBar jToolBar1;
    private JMenuItem jMenuItemAnnuler,
            jMenuItemBlanc, jMenuItemBleu, jMenuItemDefinir, jMenuItemEfface,
            jMenuItemEllipse, jMenuItemEnregistrer, jMenuItemEnregistrerSous,
            jMenuItemJaune, jMenuItemNoir, jMenuItemNouveau,
            jMenuItemOuvrir, jMenuItemProprietes,
            jMenuItemQuitter, jMenuItemRectangle, jMenuItemRemplissage,
            jMenuItemRepeter, jMenuItemRouge, jMenuItemTriangle, jMenuItemVert,
            jMenuItemVider, jMenuItemapropos;

    private JSeparator jSeparator1, jSeparator2, jSeparator3, jSeparator4,
            jSeparator5, jSeparator6, jSeparator7, jSeparator8, jSeparator9;
    static JSpinner jSpinner1, jSpinner2, jSpinner3;
    
    
    // End of variables declaration                   
}
